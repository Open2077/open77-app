OPEN//77 BRAND KIT
==================

Colors
  Void Navy  #080E19 | OPEN Electric #22D8E2 | Signal Ice #70F3F5
  Cold White #F2F6F8 | Ink Navy #0C1524      | Signal Coral #FF5964

Marks
  Wordmark   — full logotype (custom vector letterforms, do not retype)
  77 monogram — SMALL FORMATS: avatars, favicons, app icons. The two
               seven-segment sevens in Ice + Electric. Reads at 16px.
  // mark    — inline label prefix, used next to text in UI.

Files
  logo/     wordmark SVG/PNG, 77 monogram, // mark, app icon, avatar master
  favicon/  favicon.svg, 16/32/48 PNG, favicon.ico, apple-touch-icon (180)
  social/   avatars 200/512/1024 — circle-safe 77 monogram (Discord/TikTok/X),
            og-card 1200x630, X header 1500x500,
            Discord invite splash 1920x1080 + server banner 960x540,
            YouTube banner 2560x1440

OPEN//77 is an unofficial community project, not affiliated with CD PROJEKT S.A.
